#pragma once

#include <opus/hip_minimal.hpp>
#include <opus/opus.hpp>

#include "gemm_a4w4_mxfp4_4wave_traits.hpp"

using opus::operator""_I;

// ===========================================================================
// A: global -> LDS -> registers (the fp8 4-wave geometry: 128-byte rows).
// ===========================================================================
template<class T>
__device__ inline auto make_layout_ga(int lane_id, int wave_id_m, int wave_id_n, int stride_a) {
    constexpr int threads_k = T::B_K_BYTES / T::VEC_A;                 // 8
    constexpr int threads_m_per_block = T::BLOCK_SIZE / threads_k;     // 32
    constexpr int threads_m_per_wave = T::WARP_SIZE / threads_k;       // 8
    static_assert(threads_k == T::B_K / T::VEC_A_ELEMS);               // 256 fp4 / 32 fp4 per lane

    constexpr auto ga_block_shape = opus::make_tuple(
        opus::number<T::HALF_B_M / threads_m_per_block>{},             // 4  y issue
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<threads_m_per_wave>{},                            // 8  p lane / 8
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<threads_k>{},                                     // 8  p lane % 8
        opus::number<T::VEC_A>{});                                     // 16 y bytes
    constexpr auto ga_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::p_dim{}, opus::y_dim{}));

    return opus::make_layout<T::VEC_A>(
        ga_block_shape,
        opus::unfold_x_stride(ga_block_dim, ga_block_shape, opus::tuple{stride_a, 1_I}),
        opus::unfold_p_coord(ga_block_dim, opus::tuple{wave_id_n, lane_id / threads_k, wave_id_m, lane_id % threads_k}));
}

template<class T>
__device__ inline auto make_layout_sa(int wave_id_m, int wave_id_n) {
    static_assert(T::smem_sub_a == T::WARP_SIZE / (T::B_K_BYTES / T::VEC_A), "one wave issue = one chunk");

    constexpr auto sa_block_shape = opus::make_tuple(
        opus::number<T::smem_m_rep / T::NUM_WAVES>{},                  // 4  y issue
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<T::VEC_A>{});                                     // 16 y bytes
    constexpr auto sa_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));

    return opus::make_layout(
        sa_block_shape,
        opus::unfold_x_stride(sa_block_dim, sa_block_shape, opus::tuple{opus::number<T::smem_linear_wave_a + T::smem_padding>{}, 1_I}),
        opus::unfold_p_coord(sa_block_dim, opus::tuple{wave_id_n, wave_id_m}));
}

template<class T>
__device__ inline auto make_layout_ra(int lane_id, int wave_id_m) {
    static_assert(T::smem_sub_a * T::T_M == T::W_M && T::T_M == 2);
    constexpr int reads_per_operand = T::W_M * T::W_K_BYTES / T::WARP_SIZE / T::VEC_A;   // 1 b128 per fp4 operand
    static_assert(reads_per_operand == 1);
    static_assert(T::WARP_SIZE / T::W_M * T::VEC_A_ELEMS == T::W_K);   // 4 lane groups x 32 fp4 = K 128

    constexpr auto ra_block_shape = opus::make_tuple(
        opus::number<T::E_M>{},                                        // 4  y M repeat
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<T::T_M>{},                                        // 2  p r % 2
        opus::number<T::W_M / T::T_M>{},                               // 8  p r / 2
        opus::number<T::E_K>{},                                        // 2  p kk, fixed to 0 (keeps the 128 B row stride); kk -> + kk * W_K_BYTES
        opus::number<reads_per_operand>{},                             // 1  y b128 per operand
        opus::number<T::WARP_SIZE / T::W_M>{},                         // 4  p g = lane / 16
        opus::number<T::VEC_A>{});                                     // 16 y bytes
    constexpr auto ra_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::p_dim{}, opus::p_dim{}, opus::y_dim{}, opus::p_dim{}, opus::y_dim{}));
    const int lane_m = lane_id % T::W_M;
    return opus::make_layout<T::VEC_A>(
        ra_block_shape,
        opus::unfold_x_stride(ra_block_dim, ra_block_shape, opus::tuple{opus::number<T::smem_linear_wave_a + T::smem_padding>{}, 1_I}),
        opus::unfold_p_coord(ra_block_dim, opus::tuple{wave_id_m, lane_m % T::T_M, lane_m / T::T_M, 0_I, lane_id / T::W_M}));
}

template<class T>
__device__ inline auto make_layout_gb(int lane_id, int wave_id_m, int wave_id_n, int stride_b) {
    constexpr int threads_k = T::B_K_BYTES / T::VEC_B;                 // 8
    constexpr int threads_n_per_block = T::BLOCK_SIZE / threads_k;     // 32
    constexpr int threads_n_per_wave = T::WARP_SIZE / threads_k;       // 8
    static_assert(threads_k == T::B_K / T::VEC_B_ELEMS);

    constexpr auto gb_block_shape = opus::make_tuple(
        opus::number<T::HALF_B_N / threads_n_per_block>{},             // 4  y issue
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<threads_n_per_wave>{},                            // 8  p lane / 8
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<threads_k>{},                                     // 8  p lane % 8
        opus::number<T::VEC_B>{});                                     // 16 y bytes
    constexpr auto gb_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::p_dim{}, opus::y_dim{}));

    return opus::make_layout<T::VEC_B>(
        gb_block_shape,
        opus::unfold_x_stride(gb_block_dim, gb_block_shape, opus::tuple{stride_b, 1_I}),
        opus::unfold_p_coord(gb_block_dim, opus::tuple{wave_id_m, lane_id / threads_k, wave_id_n, lane_id % threads_k}));
}

template<class T>
__device__ inline auto make_layout_sb(int wave_id_m, int wave_id_n) {
    static_assert(T::smem_sub_b == T::WARP_SIZE / (T::B_K_BYTES / T::VEC_B), "one wave issue = one chunk");

    constexpr auto sb_block_shape = opus::make_tuple(
        opus::number<T::smem_n_rep / T::NUM_WAVES>{},                  // 4  y issue
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<T::VEC_B>{});                                     // 16 y bytes
    constexpr auto sb_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));

    return opus::make_layout(
        sb_block_shape,
        opus::unfold_x_stride(sb_block_dim, sb_block_shape, opus::tuple{opus::number<T::smem_linear_wave_b + T::smem_padding>{}, 1_I}),
        opus::unfold_p_coord(sb_block_dim, opus::tuple{wave_id_m, wave_id_n}));
}

template<class T>
__device__ inline auto make_layout_rb(int lane_id, int wave_id_n) {
    static_assert(T::smem_sub_b * T::T_N == T::W_N && T::T_N == 2);
    constexpr int reads_per_operand = T::W_N * T::W_K_BYTES / T::WARP_SIZE / T::VEC_B;   // 1 b128 per fp4 operand
    static_assert(reads_per_operand == 1);
    static_assert(T::WARP_SIZE / T::W_N * T::VEC_B_ELEMS == T::W_K);

    constexpr auto rb_block_shape = opus::make_tuple(
        opus::number<T::E_N>{},                                        // 4  y N repeat
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<T::T_N>{},                                        // 2  p r % 2
        opus::number<T::W_N / T::T_N>{},                               // 8  p r / 2
        opus::number<T::E_K>{},                                        // 2  p kk, fixed to 0 (keeps the 128 B row stride); kk -> + kk * W_K_BYTES
        opus::number<reads_per_operand>{},                             // 1  y b128 per operand
        opus::number<T::WARP_SIZE / T::W_N>{},                         // 4  p g = lane / 16
        opus::number<T::VEC_B>{});                                     // 16 y bytes
    constexpr auto rb_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::p_dim{}, opus::p_dim{}, opus::y_dim{}, opus::p_dim{}, opus::y_dim{}));
    const int lane_n = lane_id % T::W_N;
    return opus::make_layout<T::VEC_B>(
        rb_block_shape,
        opus::unfold_x_stride(rb_block_dim, rb_block_shape, opus::tuple{opus::number<T::smem_linear_wave_b + T::smem_padding>{}, 1_I}),
        opus::unfold_p_coord(rb_block_dim, opus::tuple{wave_id_n, lane_n % T::T_N, lane_n / T::T_N, 0_I, lane_id / T::W_N}));
}

template<class T>
__device__ inline auto make_layout_gsfa(int lane_id, int wave_id_m, int wave_id_n, int stride_sfa) {
    constexpr auto gsfa_block_shape = opus::make_tuple(
        opus::number<T::B_M / T::BLOCK_SIZE>{},                        // 1  y M repeat
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<T::WARP_SIZE>{},                                  // 64 p lane = row
        opus::number<T::VEC_GLOBAL_SCALE>{});                          // 16 y bytes
    constexpr auto gsfa_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));
    return opus::make_layout<T::VEC_GLOBAL_SCALE>(
        gsfa_block_shape,
        opus::unfold_x_stride(gsfa_block_dim, gsfa_block_shape, opus::tuple{stride_sfa, 1_I}),
        opus::unfold_p_coord(gsfa_block_dim, opus::tuple{wave_id_n, wave_id_m, lane_id}));
}

template<class T>
__device__ inline auto make_layout_ssfa(int wave_id_m, int wave_id_n) {
    constexpr int wave_bytes = T::WARP_SIZE * T::VEC_GLOBAL_SCALE;    // 1024
    constexpr auto ssfa_block_shape = opus::make_tuple(
        opus::number<T::B_M / T::BLOCK_SIZE>{},                        // 1  y M repeat
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<T::VEC_GLOBAL_SCALE>{});                          // 16 y bytes
    constexpr auto ssfa_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));
    return opus::make_layout<T::VEC_GLOBAL_SCALE>(
        ssfa_block_shape,
        opus::unfold_x_stride(ssfa_block_dim, ssfa_block_shape, opus::tuple{opus::number<wave_bytes>{}, 1_I}),
        opus::unfold_p_coord(ssfa_block_dim, opus::tuple{wave_id_n, wave_id_m}));
}

template<class T>
__device__ inline auto make_layout_gsfb(int lane_id, int wave_id_m, int wave_id_n, int stride_sfb) {
    constexpr auto gsfb_block_shape = opus::make_tuple(
        opus::number<T::B_N / T::BLOCK_SIZE>{},                        // 1  y N repeat
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<T::WARP_SIZE>{},                                  // 64 p lane = row
        opus::number<T::VEC_GLOBAL_SCALE>{});                          // 16 y bytes
    constexpr auto gsfb_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));
    return opus::make_layout<T::VEC_GLOBAL_SCALE>(
        gsfb_block_shape,
        opus::unfold_x_stride(gsfb_block_dim, gsfb_block_shape, opus::tuple{stride_sfb, 1_I}),
        opus::unfold_p_coord(gsfb_block_dim, opus::tuple{wave_id_m, wave_id_n, lane_id}));
}

template<class T>
__device__ inline auto make_layout_ssfb(int wave_id_m, int wave_id_n) {
    constexpr int wave_bytes = T::WARP_SIZE * T::VEC_GLOBAL_SCALE;    // 1024
    constexpr auto ssfb_block_shape = opus::make_tuple(
        opus::number<T::B_N / T::BLOCK_SIZE>{},                        // 1  y N repeat
        opus::number<T::T_M>{},                                        // 2  p wave_m
        opus::number<T::T_N>{},                                        // 2  p wave_n
        opus::number<T::VEC_GLOBAL_SCALE>{});                          // 16 y bytes
    constexpr auto ssfb_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));
    return opus::make_layout<T::VEC_GLOBAL_SCALE>(
        ssfb_block_shape,
        opus::unfold_x_stride(ssfb_block_dim, ssfb_block_shape, opus::tuple{opus::number<wave_bytes>{}, 1_I}),
        opus::unfold_p_coord(ssfb_block_dim, opus::tuple{wave_id_m, wave_id_n}));
}

template<class T>
__device__ inline auto make_layout_rsfa(int lane_id, int wave_id_m) {
    constexpr auto rsfa_block_shape = opus::make_tuple(
        opus::number<T::B_M / T::HALF_B_M>{},                          // 2  y half h   (128 rows)
        opus::number<T::WARP_SIZE / T::W_M>{},                         // 4  p g as e   (32 rows)
        opus::number<T::T_M>{},                                        // 2  p wave_m   (16 rows)
        opus::number<T::W_M>{},                                        // 16 p r        (1 row)
        opus::number<T::VEC_LDS_SCALE>{});                             // 8  y bytes
    constexpr auto rsfa_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));
    return opus::make_layout<T::VEC_LDS_SCALE>(
        rsfa_block_shape,
        opus::unfold_x_stride(rsfa_block_dim, rsfa_block_shape, opus::tuple{opus::number<T::VEC_GLOBAL_SCALE>{}, 1_I}),
        opus::unfold_p_coord(rsfa_block_dim, opus::tuple{lane_id / T::W_M, wave_id_m, lane_id % T::W_M}));
}

template<class T>
__device__ inline auto make_layout_rsfb(int lane_id, int wave_id_n) {
    constexpr auto rsfb_block_shape = opus::make_tuple(
        opus::number<T::B_N / T::HALF_B_N>{},                          // 2  y half h   (128 rows)
        opus::number<T::WARP_SIZE / T::W_N>{},                         // 4  p g as e   (32 rows)
        opus::number<T::T_N>{},                                        // 2  p wave_n   (16 rows)
        opus::number<T::W_N>{},                                        // 16 p r        (1 row)
        opus::number<T::VEC_LDS_SCALE>{});                             // 8  y bytes
    constexpr auto rsfb_block_dim = opus::make_tuple(
        opus::make_tuple(opus::y_dim{}, opus::p_dim{}, opus::p_dim{}, opus::p_dim{}),
        opus::make_tuple(opus::y_dim{}));
    return opus::make_layout<T::VEC_LDS_SCALE>(
        rsfb_block_shape,
        opus::unfold_x_stride(rsfb_block_dim, rsfb_block_shape, opus::tuple{opus::number<T::VEC_GLOBAL_SCALE>{}, 1_I}),
        opus::unfold_p_coord(rsfb_block_dim, opus::tuple{lane_id / T::W_N, wave_id_n, lane_id % T::W_N}));
}

__device__ inline unsigned int transpose_scale_dword_4x4(unsigned int packed, int scale_call) {
    const auto rows01_or_23 = __builtin_amdgcn_permlane16_swap(packed, packed, false, true);
    const unsigned int select_q01 = 0x06020400u + (scale_call & 1) * 0x01010101u;
    const unsigned int q01_or_q23 = __builtin_amdgcn_perm(rows01_or_23[1], rows01_or_23[0], select_q01);
    const auto rows0123 = __builtin_amdgcn_permlane32_swap(q01_or_q23, q01_or_q23, false, true);
    const unsigned int select_q = 0x05040100u + (scale_call >> 1) * 0x02020202u;
    return __builtin_amdgcn_perm(rows0123[1], rows0123[0], select_q);
}

// sched_group_barrier masks (LLVM AMDGPU)
constexpr int SCHED_VALU = 0x002;
constexpr int SCHED_MFMA = 0x008;
constexpr int SCHED_VMEM_READ = 0x820;   // 0x020 VMEM read | 0x800 LDS DMA (newer LLVM classifies buffer_load ... lds as LDS DMA)
constexpr int SCHED_DS_READ = 0x100;

// REPS x (MFMAS MFMAs, then OTHERS instructions of OTHER_MASK) in one scheduling region
// (co-execution pattern of gcnasm block_scale_gemm's sched_barrier_pairs).
template<int REPS, int MFMAS, int OTHER_MASK, int OTHERS, int GROUP = 0>
__device__ inline void sched_pairs() {
    opus::static_for<REPS>([&](auto) {
        __builtin_amdgcn_sched_group_barrier(SCHED_MFMA, MFMAS, GROUP);
        __builtin_amdgcn_sched_group_barrier(OTHER_MASK, OTHERS, GROUP);
    });
}

// REPS x one group of 4 MFMAs with DS reads (0..2), one buffer_load (0/1) and VALU
// instructions interleaved: MFMA [DS] MFMA [VMEM] MFMA [DS] MFMA [VALU x n].
template<int REPS, int DS, int VMEM, int VALU>
__device__ inline void sched_x4() {
    static_assert(DS <= 2 && VMEM <= 1);
    opus::static_for<REPS>([&](auto) {
        __builtin_amdgcn_sched_group_barrier(SCHED_MFMA, 1, 0);
        if constexpr (DS >= 1) __builtin_amdgcn_sched_group_barrier(SCHED_DS_READ, 1, 0);
        __builtin_amdgcn_sched_group_barrier(SCHED_MFMA, 1, 0);
        if constexpr (VMEM >= 1) __builtin_amdgcn_sched_group_barrier(SCHED_VMEM_READ, 1, 0);
        __builtin_amdgcn_sched_group_barrier(SCHED_MFMA, 1, 0);
        if constexpr (DS >= 2) __builtin_amdgcn_sched_group_barrier(SCHED_DS_READ, 1, 0);
        __builtin_amdgcn_sched_group_barrier(SCHED_MFMA, 1, 0);
        if constexpr (VALU > 0) __builtin_amdgcn_sched_group_barrier(SCHED_VALU, VALU, 0);
    });
}

// One scaled fp4 MFMA (repeat M_REPEAT x N_REPEAT) on one 16-byte A and B operand (one
// ds_read_b128 each, pinned to AGPRs), accumulating into one C fragment (4 fp32) pinned
// at C_REG: C_REG >= 0 -> a[C_REG], C_REG <= -2 -> v[-C_REG - 2] (so C01 / C11 can be
// pinned to VGPRs), -1 -> not pinned.  op_sel = repeat.  The base scaled MFMA takes
// 256-bit operands and reads only the low 128 bits for fp4 (upper half undefined).
template<class T, int M_REPEAT, int N_REPEAT, int C_REG, class MMA, class CF>
__device__ inline void mma_scale_one(
    MMA& mma,
    const opus::vector_t<opus::i32_t, 4>& a,
    const opus::vector_t<opus::i32_t, 4>& b,
    CF& c,
    unsigned int v_sfa,
    unsigned int v_sfb) {
    (void)mma;
    using base_mma = typename opus::remove_cvref_t<MMA>::MMA;
    using i32x8_t = opus::vector_t<opus::i32_t, 8>;
    const i32x8_t a8 = __builtin_shufflevector(a, a, 0, 1, 2, 3, -1, -1, -1, -1);
    const i32x8_t b8 = __builtin_shufflevector(b, b, 0, 1, 2, 3, -1, -1, -1, -1);
    if constexpr (C_REG >= 0) {
        [[clang::amdgpu_pin_agpr(C_REG)]] c = base_mma{}(a8, b8, c, static_cast<int>(v_sfa), static_cast<int>(v_sfb),
                                                         opus::number<M_REPEAT>{}, opus::number<N_REPEAT>{});
    } else if constexpr (C_REG <= -2) {
        [[clang::amdgpu_pin_vgpr(-C_REG - 2)]] c = base_mma{}(a8, b8, c, static_cast<int>(v_sfa), static_cast<int>(v_sfb),
                                                              opus::number<M_REPEAT>{}, opus::number<N_REPEAT>{});
    } else {
        c = base_mma{}(a8, b8, c, static_cast<int>(v_sfa), static_cast<int>(v_sfb), opus::number<M_REPEAT>{}, opus::number<N_REPEAT>{});
    }
}

// Pinned home of C fragment (m, n) of quadrant C[hm][hn]: C00 a[128:191], C10 a[192:255],
// C01 v[128:191], C11 v[192:255] (encoded as in mma_scale_one).
template<class T, int HM, int HN, int M, int N>
constexpr int c_reg() {
    constexpr int frag = (M * T::E_N + N) * 4;
    if constexpr (HN == 0) return 128 + HM * 64 + frag;           // AGPR
    else return -(128 + HM * 64 + frag) - 2;                        // VGPR
}

// ===========================================================================
// Kernel
// ===========================================================================
#ifndef BAR_STEP
#define BAR_STEP 8
#endif
template<class Traits>
__global__ __launch_bounds__(Traits::BLOCK_SIZE, 1)
void gemm_a4w4_mxfp4_4wave_kernel(opus_gemm_mxfp4_scale_kargs kargs) {
    using namespace opus;
    using T = opus::remove_cvref_t<Traits>;
    using D_A = opus::fp4_t;    // math types of the MMA
    using D_B = opus::fp4_t;
    using D_ACC = opus::fp32_t;
    using D_C = opus::bf16_t;
    using D_AB = opus::u8_t;
    using D_SF = opus::e8m0_t;  // UE8M0 scale, 1 byte (load<16> = 16 bytes)

    const int num_tiles_n = ceil_div_scale(kargs.n, T::B_N);
    const int block_m = block_id_x() / num_tiles_n;
    const int block_n = block_id_x() % num_tiles_n;
    const int loops = kargs.k / T::B_K;
    const int row = block_m * T::B_M;
    const int col = block_n * T::B_N;
    const int batch_id = block_id_z();
    const int wave_id = __builtin_amdgcn_readfirstlane(thread_id_x() / T::WARP_SIZE);
    const int lane_id = thread_id_x() % T::WARP_SIZE;
    const int wave_id_m = wave_id % T::T_M;
    const int wave_id_n = wave_id / T::T_M;

    auto g_a = make_gmem(reinterpret_cast<const D_AB*>(kargs.ptr_a) + batch_id * kargs.stride_a_batch + row * kargs.stride_a);
    auto g_b = make_gmem(reinterpret_cast<const D_AB*>(kargs.ptr_b) + batch_id * kargs.stride_b_batch + col * kargs.stride_b);
    auto g_c = make_gmem(reinterpret_cast<D_C*>(kargs.ptr_c) + batch_id * kargs.stride_c_batch + row * kargs.stride_c + col);
    auto g_sfa = make_gmem(reinterpret_cast<const D_SF*>(kargs.ptr_sfa) + batch_id * kargs.stride_sfa_batch + row * kargs.stride_sfa, static_cast<unsigned int>((kargs.m - row) * kargs.stride_sfa));
    auto g_sfb = make_gmem(reinterpret_cast<const D_SF*>(kargs.ptr_sfb) + batch_id * kargs.stride_sfb_batch + col * kargs.stride_sfb, static_cast<unsigned int>((kargs.n - col) * kargs.stride_sfb));

    const auto u_ga = make_layout_ga<T>(lane_id, wave_id_m, wave_id_n, kargs.stride_a);
    const auto u_gb = make_layout_gb<T>(lane_id, wave_id_m, wave_id_n, kargs.stride_b);
    const auto u_sa = make_layout_sa<T>(wave_id_m, wave_id_n);
    const auto u_sb = make_layout_sb<T>(wave_id_m, wave_id_n);
    const auto u_ra = make_layout_ra<T>(lane_id, wave_id_m);
    const auto u_rb = make_layout_rb<T>(lane_id, wave_id_n);
    const auto u_gsfa = make_layout_gsfa<T>(lane_id, wave_id_m, wave_id_n, kargs.stride_sfa);
    const auto u_ssfa = make_layout_ssfa<T>(wave_id_m, wave_id_n);
    const auto u_gsfb = make_layout_gsfb<T>(lane_id, wave_id_m, wave_id_n, kargs.stride_sfb);
    const auto u_ssfb = make_layout_ssfb<T>(wave_id_m, wave_id_n);
    const auto u_rsfa = make_layout_rsfa<T>(lane_id, wave_id_m);
    const auto u_rsfb = make_layout_rsfb<T>(lane_id, wave_id_n);

    constexpr int smem_a_elem = T::smem_m_rep * (T::smem_linear_wave_a + T::smem_padding); 
    constexpr int smem_b_elem = T::smem_n_rep * (T::smem_linear_wave_b + T::smem_padding);
    // A and B LDS stages are one contiguous block: the epilogue reuses all of it as
    // the bf16 C image (256 x 264 x 2 B = 135168 B = SMEM_A + SMEM_B).
    constexpr int smem_a_bytes = smem_a_elem * 4 * sizeof(D_A);
    constexpr int smem_b_bytes = smem_b_elem * 4 * sizeof(D_B);
    __shared__ __attribute__((aligned(16))) char smem_ab[smem_a_bytes + smem_b_bytes];
    char* const smem_a = smem_ab;
    char* const smem_b = smem_ab + smem_a_bytes;
    __shared__ char smem_sfa[T::SCALE_PANEL_BUFFERS * T::SFA_PANEL_BYTES * sizeof(D_SF)];
    __shared__ char smem_sfb[T::SCALE_PANEL_BUFFERS * T::SFB_PANEL_BYTES * sizeof(D_SF)];
    auto s_a = make_smem(reinterpret_cast<D_AB*>(smem_a));
    auto s_b = make_smem(reinterpret_cast<D_AB*>(smem_b));
    auto s_sfa = make_smem(reinterpret_cast<D_SF*>(smem_sfa));
    auto s_sfb = make_smem(reinterpret_cast<D_SF*>(smem_sfb));

    auto mma = make_tiled_mma<D_A, D_B, D_ACC>(
        seq<T::E_M, T::E_N, 1>{},          // K: one MFMA (W_K = 128); the E_K = 2 steps are v_a[.][kk]
        seq<T::T_M, T::T_N, T::T_K>{},
        seq<T::W_M, T::W_N, T::W_K>{},
        mfma_adaptor_swap_ab{});
    using MMA = decltype(mma);
    static_assert(MMA::mma_a_len == T::W_K_BYTES * T::ELEMS_PER_BYTE / (T::WARP_SIZE / T::W_M));  // 32 fp4 per lane
    using DW4 = opus::vector_t<opus::i32_t, 4>;
    // A / B operands, one ds_read_b128 each, pinned: A0 a[0:31], A1 a[32:63], B0 a[64:95], B1 a[96:127];
    // inside a half, operand (kk, repeat) at + (kk * 4 + repeat) * 4.
    DW4 v_a[2][T::E_K][T::E_M];   // [half][kk]: E_M fp4 operands, 16 B each
    DW4 v_b[2][T::E_K][T::E_N];
    using CFrag = opus::vector_t<D_ACC, MMA::mma_c_len>;   // one 16x16 C fragment, 4 fp32 per lane
    CFrag v_c[2][2][T::E_M * T::E_N];
    opus::static_for<2>([&](auto hm) { opus::static_for<2>([&](auto hn) { opus::static_for<T::E_M * T::E_N>([&](auto f) {
        clear(v_c[hm.value][hn.value][f.value]);
    }); }); });

    using D_SF_PACK = opus::u32_t;
    D_SF_PACK v_sfa[2][T::E_K];
    D_SF_PACK v_sfb[2][T::E_K];
    D_SF_PACK v_sfa_next[2][T::E_K];
    D_SF_PACK v_sfb_next[2][T::E_K];

    // ---- offsets ----
    auto ga_offset = [&](int half_tile_m, int tile_k) { return half_tile_m * T::HALF_B_M * kargs.stride_a + tile_k * T::B_K_BYTES; };
    auto gb_offset = [&](int half_tile_n, int tile_k) { return half_tile_n * T::HALF_B_N * kargs.stride_b + tile_k * T::B_K_BYTES; };
    auto sa_offset = [&](int stage, int half_tile_m) { return (stage * 2 + half_tile_m) * smem_a_elem; };
    auto sb_offset = [&](int stage, int half_tile_n) { return (stage * 2 + half_tile_n) * smem_b_elem; };
    auto gsfa_offset = [&](int panel_k_begin) { return panel_k_begin * T::NUM_KGROUPS; };
    auto gsfb_offset = [&](int panel_k_begin) { return panel_k_begin * T::NUM_KGROUPS; };
    // Scale LDS: stage = panel buffer (switches every SCALE_PANEL_TILES K tiles), tile_in_panel = 8-byte slot in the row.
    auto ssfa_offset = [&](int stage, int tile_in_panel) { return stage * T::SFA_PANEL_BYTES + tile_in_panel * T::NUM_KGROUPS; };
    auto ssfb_offset = [&](int stage, int tile_in_panel) { return stage * T::SFB_PANEL_BYTES + tile_in_panel * T::NUM_KGROUPS; };

    // ---- global -> LDS ----
    auto prefetch_a = [&](int stage, int tile, int half_tile_m) {
        async_load<T::VEC_A>(g_a, s_a.ptr, u_ga, u_sa + sa_offset(stage, half_tile_m), ga_offset(half_tile_m, tile));
    };
    auto prefetch_b = [&](int stage, int tile, int half_tile_n) {
        async_load<T::VEC_B>(g_b, s_b.ptr, u_gb, u_sb + sb_offset(stage, half_tile_n), gb_offset(half_tile_n, tile));
    };
    // Variants with the panel buffer index given (the main loop tracks it instead of % 3).
    auto prefetch_sfa_buf = [&](int panel_k_begin, int buf) {
        async_load<T::VEC_GLOBAL_SCALE>(g_sfa, s_sfa.ptr, u_gsfa, u_ssfa + ssfa_offset(buf, 0), gsfa_offset(panel_k_begin));
    };
    auto prefetch_sfb_buf = [&](int panel_k_begin, int buf) {
        async_load<T::VEC_GLOBAL_SCALE>(g_sfb, s_sfb.ptr, u_gsfb, u_ssfb + ssfb_offset(buf, 0), gsfb_offset(panel_k_begin));
    };
    auto prefetch_sfa = [&](int panel_k_begin) {
        async_load<T::VEC_GLOBAL_SCALE>(g_sfa, s_sfa.ptr, u_gsfa, u_ssfa + ssfa_offset((panel_k_begin / T::SCALE_PANEL_TILES) % T::SCALE_PANEL_BUFFERS, 0), gsfa_offset(panel_k_begin));
    };
    auto prefetch_sfb = [&](int panel_k_begin) {
        async_load<T::VEC_GLOBAL_SCALE>(g_sfb, s_sfb.ptr, u_gsfb, u_ssfb + ssfb_offset((panel_k_begin / T::SCALE_PANEL_TILES) % T::SCALE_PANEL_BUFFERS, 0), gsfb_offset(panel_k_begin));
    };

    // ---- LDS -> VGPR ----
    const auto ra_offs = opus::layout_to_offsets<T::VEC_A>(u_ra);   // [repeat]
    const auto rb_offs = opus::layout_to_offsets<T::VEC_B>(u_rb);
    // Same reads through another view of the LDS (a __restrict__ pointer in the main
    // loop): A / B relative to the stage base, scales relative to the panel base.
    // Operand (kk, repeat) of A half `half`: one ds_read_b128, pinned to its AGPRs.
    auto load_a_at = [&](auto& sa_, auto half_, int stage_offset = 0) {
        constexpr int half = decltype(half_)::value;
        opus::static_for<T::E_K>([&](auto kk) { opus::static_for<T::E_M>([&](auto e) {
            constexpr int agpr = 0 + half * 32 + (kk.value * T::E_M + e.value) * 4;
            [[clang::amdgpu_pin_agpr(agpr)]] v_a[half][kk.value][e.value] =
                __builtin_bit_cast(DW4, load<T::VEC_A>(sa_, ra_offs[e.value] + stage_offset + sa_offset(0, half) + kk.value * T::W_K_BYTES));
        }); });
    };
    // Operand (kk, repeat) of B half `half`: one ds_read_b128, pinned to its AGPRs.
    auto load_b_at = [&](auto& sb_, auto half_, int stage_offset = 0) {
        constexpr int half = decltype(half_)::value;
        opus::static_for<T::E_K>([&](auto kk) { opus::static_for<T::E_N>([&](auto e) {
            constexpr int agpr = 64 + half * 32 + (kk.value * T::E_N + e.value) * 4;
            [[clang::amdgpu_pin_agpr(agpr)]] v_b[half][kk.value][e.value] =
                __builtin_bit_cast(DW4, load<T::VEC_B>(sb_, rb_offs[e.value] + stage_offset + sb_offset(0, half) + kk.value * T::W_K_BYTES));
        }); });
    };
    auto load_a = [&](int stage, auto half_) { load_a_at(s_a, half_, sa_offset(stage, 0)); };
    auto load_b = [&](int stage, auto half_) { load_b_at(s_b, half_, sb_offset(stage, 0)); };
    opus::vector_t<D_SF, 2 * T::VEC_LDS_SCALE> v_sfa_raw, v_sfb_raw;  
    auto load_sfa = [&](int tile) { v_sfa_raw = load<T::VEC_LDS_SCALE>(s_sfa, u_rsfa + ssfa_offset((tile / T::SCALE_PANEL_TILES) % T::SCALE_PANEL_BUFFERS, tile % T::SCALE_PANEL_TILES)); };
    auto load_sfa_at = [&](auto& ssfa_, int tile) { v_sfa_raw = load<T::VEC_LDS_SCALE>(ssfa_, u_rsfa + ssfa_offset((tile / T::SCALE_PANEL_TILES) % T::SCALE_PANEL_BUFFERS, tile % T::SCALE_PANEL_TILES)); };
    auto load_sfb_at = [&](auto& ssfb_, int tile) { v_sfb_raw = load<T::VEC_LDS_SCALE>(ssfb_, u_rsfb + ssfb_offset((tile / T::SCALE_PANEL_TILES) % T::SCALE_PANEL_BUFFERS, tile % T::SCALE_PANEL_TILES)); };
    auto load_sfa_buf = [&](auto& ssfa_, int buf, int tile_in_panel) { v_sfa_raw = load<T::VEC_LDS_SCALE>(ssfa_, u_rsfa + ssfa_offset(buf, tile_in_panel)); };
    auto load_sfb_buf = [&](auto& ssfb_, int buf, int tile_in_panel) { v_sfb_raw = load<T::VEC_LDS_SCALE>(ssfb_, u_rsfb + ssfb_offset(buf, tile_in_panel)); };
    auto load_sfb = [&](int tile) { v_sfb_raw = load<T::VEC_LDS_SCALE>(s_sfb, u_rsfb + ssfb_offset((tile / T::SCALE_PANEL_TILES) % T::SCALE_PANEL_BUFFERS, tile % T::SCALE_PANEL_TILES)); };

    //
    // Before (load<8> x 2 halves = 16 e8m0, row-major; lane 16g+r holds row g*32+r and row 128+g*32+r):
    //            dword0 [0][0]        dword1 [0][1]        dword2 [1][0]                dword3 [1][1]
    // lane 0     M0k0  M0k1  M0k2  M0k3   M0k4  M0k5  M0k6  M0k7   M128k0 M128k1 M128k2 M128k3   M128k4 M128k5 M128k6 M128k7
    // lane 16    M32k0 M32k1 M32k2 M32k3  M32k4 M32k5 M32k6 M32k7  M160k0 M160k1 M160k2 M160k3   M160k4 M160k5 M160k6 M160k7
    // lane 32    M64k0 M64k1 M64k2 M64k3  M64k4 M64k5 M64k6 M64k7  M192k0 M192k1 M192k2 M192k3   M192k4 M192k5 M192k6 M192k7
    // lane 48    M96k0 M96k1 M96k2 M96k3  M96k4 M96k5 M96k6 M96k7  M224k0 M224k1 M224k2 M224k3   M224k4 M224k5 M224k6 M224k7
    //
    // After (byte e = repeat e, picked by op_sel; lane group g = K group g of the MFMA):
    //            v_sfa[0][0]           v_sfa[0][1]           v_sfa[1][0]                 v_sfa[1][1]
    // lane 0     M0k0 M32k0 M64k0 M96k0  M0k4 M32k4 M64k4 M96k4  M128k0 M160k0 M192k0 M224k0  M128k4 M160k4 M192k4 M224k4
    // lane 16    M0k1 M32k1 M64k1 M96k1  M0k5 M32k5 M64k5 M96k5  M128k1 M160k1 M192k1 M224k1  M128k5 M160k5 M192k5 M224k5
    // lane 32    M0k2 M32k2 M64k2 M96k2  M0k6 M32k6 M64k6 M96k6  M128k2 M160k2 M192k2 M224k2  M128k6 M160k6 M192k6 M224k6
    // lane 48    M0k3 M32k3 M64k3 M96k3  M0k7 M32k7 M64k7 M96k7  M128k3 M160k3 M192k3 M224k3  M128k7 M160k7 M192k7 M224k7
    //
    using SF_DW = opus::vector_t<D_SF_PACK, 2 * T::E_K>;
    auto transpose_sfa = [&](D_SF_PACK (&sfa)[2][T::E_K]) {
        const auto dw = __builtin_bit_cast(SF_DW, v_sfa_raw);
        opus::static_for<2 * T::E_K>([&](auto i) {
            sfa[i.value / T::E_K][i.value % T::E_K] = transpose_scale_dword_4x4(dw[i.value], lane_id / T::W_M);
        });
    };
    auto transpose_sfb = [&](D_SF_PACK (&sfb)[2][T::E_K]) {
        const auto dw = __builtin_bit_cast(SF_DW, v_sfb_raw);
        opus::static_for<2 * T::E_K>([&](auto i) {
            sfb[i.value / T::E_K][i.value % T::E_K] = transpose_scale_dword_4x4(dw[i.value], lane_id / T::W_N);
        });
    };

    // ===== Prologue =====
    constexpr int frags = T::E_M * T::E_N;   // 16 (m, n) steps per quadrant, 2 MFMAs each
    // Issue tile 0 and scale panel 0, then tile 1 and panel 1 (tile 2, 3); wait only for
    // tile 0 + panel 0 (counted vmcnt), read A0 / B0 and the scales of tile 0, and compute
    // C00 of tile 0 while A1 / B1 of tile 0 are read.  The main loop then starts with
    // "C00 of tile t is done".
    prefetch_a(0, 0, 0);
    prefetch_b(0, 0, 0);
    prefetch_a(0, 0, 1);
    prefetch_b(0, 0, 1);
    prefetch_sfa(0);
    prefetch_sfb(0);
    if (loops > 1) {
        prefetch_a(1, 1, 0);
        prefetch_b(1, 1, 0);
        prefetch_a(1, 1, 1);
        prefetch_b(1, 1, 1);
    }
    if (loops > T::SCALE_PANEL_TILES) {
        prefetch_sfa(T::SCALE_PANEL_TILES);
        prefetch_sfb(T::SCALE_PANEL_TILES);
        s_waitcnt_vmcnt(number<4 * T::a_buffer_load_insts + 2>{});      // tile 1 + panel 1 may fly
    } else if (loops > 1) {
        s_waitcnt_vmcnt(number<4 * T::a_buffer_load_insts>{});          // tile 1 may fly
    } else {
        s_waitcnt_vmcnt(0_I);
    }
    __builtin_amdgcn_s_barrier();
    __builtin_amdgcn_sched_barrier(0);
    load_a(0, number<0>{});
    load_b(0, number<0>{});
    load_sfa(0);
    load_sfb(0);
    transpose_sfa(v_sfa);
    transpose_sfb(v_sfb);
    __builtin_amdgcn_sched_barrier(0);
    // C00 of tile 0 + A1, B1 of tile 0.
    load_a(0, number<1>{});
    load_b(0, number<1>{});
    opus::static_for<frags>([&](auto i) {
        constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
        mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][0][m], v_b[0][0][n], v_c[0][0][m * T::E_N + n], v_sfa[0][0], v_sfb[0][0]);   // kk = 0
        mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][1][m], v_b[0][1][n], v_c[0][0][m * T::E_N + n], v_sfa[0][1], v_sfb[0][1]);   // kk = 1
    });
    sched_x4<8, 2, 0, 0>();
    __builtin_amdgcn_sched_barrier(0);

    // ===== Main loop =====
    // Rotated, as gcnasm block_scale_gemm: entering iteration t, C00 of tile t is done,
    // A0 / B0 / A1 / B1 of tile t are in registers (A1 / B1 possibly still landing),
    // tile t+1 is in (or landing in) LDS next_stage.  Iteration t computes C10, C01, C11
    // of tile t and C00 of tile t+1:
    //   B_a  lgkmcnt(0) + barrier          stage(t) fully read -> may be overwritten
    //   C10(t)    A0, B0 of tile t+2 -> stage(t)                  (8 buffer_loads)
    //   B_b  vmcnt(8) + barrier            tile t+1 landed
    //   C01(t)    scales + B0 of tile t+1 -> registers; A1, B1 of tile t+2 (8 buffer_loads)
    //   C11(t)    A0 of tile t+1 -> registers; scale transposes; scale panel copy before it
    //   C00(t+1)  A1, B1 of tile t+1 -> registers (16 DS over 32 MFMAs)
    // Every register half is reloaded only after its last use in this order (B0 after
    // C10, A0 after C01, A1 / B1 after C11).  One step = 2 MFMAs (kk = 0, 1); each region
    // interleaves its DS reads / buffer_loads / VALU with the MFMAs (sched_x4).
    // The reads of an iteration (tile t+1 in stage next_stage, the scale panels) go through
    // __restrict__ views, as in opus_gemm_pipeline_mxfp8_nn_4wave: they never touch the bytes
    // the iteration's LDS-DMA copies write (tile t+2 in stage(t), a later scale panel), and
    // without that knowledge the compiler puts a vmcnt(0) before every such ds_read.
    auto views = [&](OPUS_LDS_ADDR char* __restrict__ read_a, OPUS_LDS_ADDR char* __restrict__ read_b,
                     OPUS_LDS_ADDR char* __restrict__ read_sfa, OPUS_LDS_ADDR char* __restrict__ read_sfb, auto&& body) {
        auto rd_a = s_a;     rd_a.ptr = read_a;
        auto rd_b = s_b;     rd_b.ptr = read_b;
        auto rd_sfa = s_sfa; rd_sfa.ptr = read_sfa;
        auto rd_sfb = s_sfb; rd_sfb.ptr = read_sfb;
        body(rd_a, rd_b, rd_sfa, rd_sfb);
    };
    int tile = 0;
    // Scale panel buffers tracked instead of (k / 2) % 3: sf_rd holds the panel of tile t+1,
    // sf_wr = sf_rd + 1 (mod 3) receives the panel copied in iteration t (t+3 for odd t,
    // t+2 for even t -- both one panel after tile t+1's); after an even t, sf_rd advances.
    int sf_rd = 0;
    // Two tiles per trip: stage / next_stage and the panel parity are compile-time in each
    // copy; A / B / C are pinned, so both copies use the same registers.
#pragma clang loop unroll(disable)
    for (; tile + 3 < loops; tile += 2) {
        {   // even tile
            constexpr int stage = 0;
            constexpr int next_stage = 1;
            const int sf_wr = sf_rd == T::SCALE_PANEL_BUFFERS - 1 ? 0 : sf_rd + 1;
            views(s_a.ptr + sa_offset(next_stage, 0), s_b.ptr + sb_offset(next_stage, 0), s_sfa.ptr, s_sfb.ptr,
                  [&](auto& rd_a, auto& rd_b, auto& rd_sfa, auto& rd_sfb) {
                // B_a: every wave is done reading stage(t) (A1 / B1 of tile t in C00), so
                // tile t+2 may be copied into it.
                s_waitcnt_lgkmcnt(0_I);
                __builtin_amdgcn_s_barrier();
                __builtin_amdgcn_sched_barrier(0);

                // C10(t) + A0, B0 of tile t+2 -> stage(t), one buffer_load per 4 MFMAs.
                prefetch_a(stage, tile + 2, 0);
                prefetch_b(stage, tile + 2, 0);
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][0][m], v_b[0][0][n], v_c[1][0][m * T::E_N + n], v_sfa[1][0], v_sfb[0][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][1][m], v_b[0][1][n], v_c[1][0][m * T::E_N + n], v_sfa[1][1], v_sfb[0][1]);   // kk = 1
                });
                sched_x4<8, 0, 1, 0>();
                __builtin_amdgcn_sched_barrier(0);
                // B_b: tile t+1 (and its scale panel) landed; the 8 copies just issued may still fly.
                s_waitcnt_vmcnt(number<2 * T::a_buffer_load_insts>{});
                __builtin_amdgcn_s_barrier();
                __builtin_amdgcn_sched_barrier(0);

                // C01(t) + scales and B0 of tile t+1 + A1, B1 of tile t+2.
                load_sfa_buf(rd_sfa, sf_rd, 1);
                load_sfb_buf(rd_sfb, sf_rd, 1);
                load_b_at(rd_b, number<0>{});
                prefetch_a(stage, tile + 2, 1);
                prefetch_b(stage, tile + 2, 1);
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][0][m], v_b[1][0][n], v_c[0][1][m * T::E_N + n], v_sfa[0][0], v_sfb[1][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][1][m], v_b[1][1][n], v_c[0][1][m * T::E_N + n], v_sfa[0][1], v_sfb[1][1]);   // kk = 1
                });
                sched_x4<4, 2, 1, 0>();
                sched_x4<4, 1, 1, 0>();
                __builtin_amdgcn_sched_barrier(0);

                // Scale panel copies, split over two tiles (one panel instruction touches 64 cache
                // lines, ~5x an A/B copy on the TA): odd t -> sfa, even t -> sfb of the panel
                // starting at t + 3 / t + 2.  With 3 panel buffers it overwrites the panel three
                // back (read long ago) and lands before the B_b that reads it.  A runtime branch,
                // so it sits on a region boundary.
                // The two branches end in different (empty) asm, so the compiler cannot merge
                // their tails into one copy that selects between the sfa / sfb layouts (that
                // selection goes through scratch, whose vmcnt wait drains every copy in flight).
                prefetch_sfb_buf(tile + 2, sf_wr);                 // even tile: sfb of the panel starting at tile + 2
                __builtin_amdgcn_sched_barrier(0);

                // C11(t) + A0 of tile t+1, scale transposes.
                load_a_at(rd_a, number<0>{});
                transpose_sfa(v_sfa_next);
                transpose_sfb(v_sfb_next);
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][0][m], v_b[1][0][n], v_c[1][1][m * T::E_N + n], v_sfa[1][0], v_sfb[1][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][1][m], v_b[1][1][n], v_c[1][1][m * T::E_N + n], v_sfa[1][1], v_sfb[1][1]);   // kk = 1
                });
                sched_x4<8, 1, 0, 2>();
                __builtin_amdgcn_sched_barrier(0);
                opus::static_for<2>([&](auto h) { opus::static_for<T::E_K>([&](auto kk) {
                    v_sfa[h.value][kk.value] = v_sfa_next[h.value][kk.value];
                    v_sfb[h.value][kk.value] = v_sfb_next[h.value][kk.value];
                }); });

                // C00(t+1) + A1, B1 of tile t+1 (16 DS, one per 2 MFMAs).
                load_a_at(rd_a, number<1>{});
                load_b_at(rd_b, number<1>{});
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][0][m], v_b[0][0][n], v_c[0][0][m * T::E_N + n], v_sfa[0][0], v_sfb[0][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][1][m], v_b[0][1][n], v_c[0][0][m * T::E_N + n], v_sfa[0][1], v_sfb[0][1]);   // kk = 1
                });
                sched_x4<8, 2, 0, 0>();
                __builtin_amdgcn_sched_barrier(0);
            });
            sf_rd = sf_wr;                                     // advances after an even tile
        }
        {   // odd tile
            const int tile_odd = tile + 1;
            const int tile = tile_odd;
            constexpr int stage = 1;
            constexpr int next_stage = 0;
            const int sf_wr = sf_rd == T::SCALE_PANEL_BUFFERS - 1 ? 0 : sf_rd + 1;
            views(s_a.ptr + sa_offset(next_stage, 0), s_b.ptr + sb_offset(next_stage, 0), s_sfa.ptr, s_sfb.ptr,
                  [&](auto& rd_a, auto& rd_b, auto& rd_sfa, auto& rd_sfb) {
                // B_a: every wave is done reading stage(t) (A1 / B1 of tile t in C00), so
                // tile t+2 may be copied into it.
                s_waitcnt_lgkmcnt(0_I);
                __builtin_amdgcn_s_barrier();
                __builtin_amdgcn_sched_barrier(0);

                // C10(t) + A0, B0 of tile t+2 -> stage(t), one buffer_load per 4 MFMAs.
                prefetch_a(stage, tile + 2, 0);
                prefetch_b(stage, tile + 2, 0);
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][0][m], v_b[0][0][n], v_c[1][0][m * T::E_N + n], v_sfa[1][0], v_sfb[0][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][1][m], v_b[0][1][n], v_c[1][0][m * T::E_N + n], v_sfa[1][1], v_sfb[0][1]);   // kk = 1
                });
                sched_x4<8, 0, 1, 0>();
                __builtin_amdgcn_sched_barrier(0);
                // B_b: tile t+1 (and its scale panel) landed; the 8 copies just issued may still fly.
                s_waitcnt_vmcnt(number<2 * T::a_buffer_load_insts>{});
                __builtin_amdgcn_s_barrier();
                __builtin_amdgcn_sched_barrier(0);

                // C01(t) + scales and B0 of tile t+1 + A1, B1 of tile t+2.
                load_sfa_buf(rd_sfa, sf_rd, 0);
                load_sfb_buf(rd_sfb, sf_rd, 0);
                load_b_at(rd_b, number<0>{});
                prefetch_a(stage, tile + 2, 1);
                prefetch_b(stage, tile + 2, 1);
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][0][m], v_b[1][0][n], v_c[0][1][m * T::E_N + n], v_sfa[0][0], v_sfb[1][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][1][m], v_b[1][1][n], v_c[0][1][m * T::E_N + n], v_sfa[0][1], v_sfb[1][1]);   // kk = 1
                });
                sched_x4<4, 2, 1, 0>();
                sched_x4<4, 1, 1, 0>();
                __builtin_amdgcn_sched_barrier(0);

                // Scale panel copies, split over two tiles (one panel instruction touches 64 cache
                // lines, ~5x an A/B copy on the TA): odd t -> sfa, even t -> sfb of the panel
                // starting at t + 3 / t + 2.  With 3 panel buffers it overwrites the panel three
                // back (read long ago) and lands before the B_b that reads it.  A runtime branch,
                // so it sits on a region boundary.
                // The two branches end in different (empty) asm, so the compiler cannot merge
                // their tails into one copy that selects between the sfa / sfb layouts (that
                // selection goes through scratch, whose vmcnt wait drains every copy in flight).
                // odd tile: sfa of the panel starting at tile + 3; past the last panel it only
                // overwrites the buffer of a consumed panel (harmless), so no branch.
                prefetch_sfa_buf(tile + 3, sf_wr);
                __builtin_amdgcn_sched_barrier(0);

                // C11(t) + A0 of tile t+1, scale transposes.
                load_a_at(rd_a, number<0>{});
                transpose_sfa(v_sfa_next);
                transpose_sfb(v_sfb_next);
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][0][m], v_b[1][0][n], v_c[1][1][m * T::E_N + n], v_sfa[1][0], v_sfb[1][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][1][m], v_b[1][1][n], v_c[1][1][m * T::E_N + n], v_sfa[1][1], v_sfb[1][1]);   // kk = 1
                });
                sched_x4<8, 1, 0, 2>();
                __builtin_amdgcn_sched_barrier(0);
                opus::static_for<2>([&](auto h) { opus::static_for<T::E_K>([&](auto kk) {
                    v_sfa[h.value][kk.value] = v_sfa_next[h.value][kk.value];
                    v_sfb[h.value][kk.value] = v_sfb_next[h.value][kk.value];
                }); });

                // C00(t+1) + A1, B1 of tile t+1 (16 DS, one per 2 MFMAs).
                load_a_at(rd_a, number<1>{});
                load_b_at(rd_b, number<1>{});
                opus::static_for<frags>([&](auto i) {
                    constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                    mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][0][m], v_b[0][0][n], v_c[0][0][m * T::E_N + n], v_sfa[0][0], v_sfb[0][0]);   // kk = 0
                    mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][1][m], v_b[0][1][n], v_c[0][0][m * T::E_N + n], v_sfa[0][1], v_sfb[0][1]);   // kk = 1
                });
                sched_x4<8, 2, 0, 0>();
                __builtin_amdgcn_sched_barrier(0);
            });
        }
    }
    // At most one more steady iteration (odd number of them).
#pragma clang loop unroll(disable)
    for (; tile + 2 < loops; ++tile) {
        const int stage = tile & 1;
        const int next_stage = stage ^ 1;
        const int sf_wr = sf_rd == T::SCALE_PANEL_BUFFERS - 1 ? 0 : sf_rd + 1;
        views(s_a.ptr + sa_offset(next_stage, 0), s_b.ptr + sb_offset(next_stage, 0), s_sfa.ptr, s_sfb.ptr,
              [&](auto& rd_a, auto& rd_b, auto& rd_sfa, auto& rd_sfb) {
            // B_a: every wave is done reading stage(t) (A1 / B1 of tile t in C00), so
            // tile t+2 may be copied into it.
            s_waitcnt_lgkmcnt(0_I);
            __builtin_amdgcn_s_barrier();
            __builtin_amdgcn_sched_barrier(0);

            // C10(t) + A0, B0 of tile t+2 -> stage(t), one buffer_load per 4 MFMAs.
            prefetch_a(stage, tile + 2, 0);
            prefetch_b(stage, tile + 2, 0);
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][0][m], v_b[0][0][n], v_c[1][0][m * T::E_N + n], v_sfa[1][0], v_sfb[0][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][1][m], v_b[0][1][n], v_c[1][0][m * T::E_N + n], v_sfa[1][1], v_sfb[0][1]);   // kk = 1
            });
            sched_x4<8, 0, 1, 0>();
            __builtin_amdgcn_sched_barrier(0);
            // B_b: tile t+1 (and its scale panel) landed; the 8 copies just issued may still fly.
            s_waitcnt_vmcnt(number<2 * T::a_buffer_load_insts>{});
            __builtin_amdgcn_s_barrier();
            __builtin_amdgcn_sched_barrier(0);

            // C01(t) + scales and B0 of tile t+1 + A1, B1 of tile t+2.
            load_sfa_buf(rd_sfa, sf_rd, (tile + 1) & 1);
            load_sfb_buf(rd_sfb, sf_rd, (tile + 1) & 1);
            load_b_at(rd_b, number<0>{});
            prefetch_a(stage, tile + 2, 1);
            prefetch_b(stage, tile + 2, 1);
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][0][m], v_b[1][0][n], v_c[0][1][m * T::E_N + n], v_sfa[0][0], v_sfb[1][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][1][m], v_b[1][1][n], v_c[0][1][m * T::E_N + n], v_sfa[0][1], v_sfb[1][1]);   // kk = 1
            });
            sched_x4<4, 2, 1, 0>();
            sched_x4<4, 1, 1, 0>();
            __builtin_amdgcn_sched_barrier(0);

            // Scale panel copies, split over two tiles (one panel instruction touches 64 cache
            // lines, ~5x an A/B copy on the TA): odd t -> sfa, even t -> sfb of the panel
            // starting at t + 3 / t + 2.  With 3 panel buffers it overwrites the panel three
            // back (read long ago) and lands before the B_b that reads it.  A runtime branch,
            // so it sits on a region boundary.
            // The two branches end in different (empty) asm, so the compiler cannot merge
            // their tails into one copy that selects between the sfa / sfb layouts (that
            // selection goes through scratch, whose vmcnt wait drains every copy in flight).
            if (tile & 1) {
                if (tile + 3 < loops) prefetch_sfa_buf(tile + 3, sf_wr);
                asm volatile("; panel copy: sfa" ::: "memory");
            } else {
                prefetch_sfb_buf(tile + 2, sf_wr);
                asm volatile("; panel copy: sfb" ::: "memory");
            }
            __builtin_amdgcn_sched_barrier(0);

            // C11(t) + A0 of tile t+1, scale transposes.
            load_a_at(rd_a, number<0>{});
            transpose_sfa(v_sfa_next);
            transpose_sfb(v_sfb_next);
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][0][m], v_b[1][0][n], v_c[1][1][m * T::E_N + n], v_sfa[1][0], v_sfb[1][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][1][m], v_b[1][1][n], v_c[1][1][m * T::E_N + n], v_sfa[1][1], v_sfb[1][1]);   // kk = 1
            });
            sched_x4<8, 1, 0, 2>();
            __builtin_amdgcn_sched_barrier(0);
            opus::static_for<2>([&](auto h) { opus::static_for<T::E_K>([&](auto kk) {
                v_sfa[h.value][kk.value] = v_sfa_next[h.value][kk.value];
                v_sfb[h.value][kk.value] = v_sfb_next[h.value][kk.value];
            }); });

            // C00(t+1) + A1, B1 of tile t+1 (16 DS, one per 2 MFMAs).
            load_a_at(rd_a, number<1>{});
            load_b_at(rd_b, number<1>{});
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][0][m], v_b[0][0][n], v_c[0][0][m * T::E_N + n], v_sfa[0][0], v_sfb[0][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][1][m], v_b[0][1][n], v_c[0][0][m * T::E_N + n], v_sfa[0][1], v_sfb[0][1]);   // kk = 1
            });
            sched_x4<8, 2, 0, 0>();
            __builtin_amdgcn_sched_barrier(0);
        });
        sf_rd = (tile & 1) ? sf_rd : sf_wr;
    }

    // ===== Epilogue =====
    // 1. Second-to-last tile: C10, C01, C11 of it and C00 of the last tile; no more copies.
    if (tile + 1 < loops) {
        const int next_stage = (tile & 1) ^ 1;
        views(s_a.ptr + sa_offset(next_stage, 0), s_b.ptr + sb_offset(next_stage, 0), s_sfa.ptr, s_sfb.ptr,
              [&](auto& rd_a, auto& rd_b, auto& rd_sfa, auto& rd_sfb) {
            // C10(t).
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][0][m], v_b[0][0][n], v_c[1][0][m * T::E_N + n], v_sfa[1][0], v_sfb[0][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][1][m], v_b[0][1][n], v_c[1][0][m * T::E_N + n], v_sfa[1][1], v_sfb[0][1]);   // kk = 1
            });
            sched_x4<8, 0, 0, 0>();
            __builtin_amdgcn_sched_barrier(0);
            // B_b: tile t+1 (and its scale panel) landed.
            s_waitcnt_vmcnt(0_I);
            __builtin_amdgcn_s_barrier();
            __builtin_amdgcn_sched_barrier(0);

            // C01(t) + scales and B0 of tile t+1.
            load_sfa_at(rd_sfa, tile + 1);
            load_sfb_at(rd_sfb, tile + 1);
            load_b_at(rd_b, number<0>{});
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][0][m], v_b[1][0][n], v_c[0][1][m * T::E_N + n], v_sfa[0][0], v_sfb[1][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][1][m], v_b[1][1][n], v_c[0][1][m * T::E_N + n], v_sfa[0][1], v_sfb[1][1]);   // kk = 1
            });
            sched_x4<4, 2, 0, 0>();
            sched_x4<4, 1, 0, 0>();
            __builtin_amdgcn_sched_barrier(0);

            // C11(t) + A0 of tile t+1, scale transposes.
            load_a_at(rd_a, number<0>{});
            transpose_sfa(v_sfa_next);
            transpose_sfb(v_sfb_next);
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][0][m], v_b[1][0][n], v_c[1][1][m * T::E_N + n], v_sfa[1][0], v_sfb[1][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][1][m], v_b[1][1][n], v_c[1][1][m * T::E_N + n], v_sfa[1][1], v_sfb[1][1]);   // kk = 1
            });
            sched_x4<8, 1, 0, 2>();
            __builtin_amdgcn_sched_barrier(0);
            opus::static_for<2>([&](auto h) { opus::static_for<T::E_K>([&](auto kk) {
                v_sfa[h.value][kk.value] = v_sfa_next[h.value][kk.value];
                v_sfb[h.value][kk.value] = v_sfb_next[h.value][kk.value];
            }); });

            // C00(t+1) + A1, B1 of tile t+1 (16 DS, one per 2 MFMAs).
            load_a_at(rd_a, number<1>{});
            load_b_at(rd_b, number<1>{});
            opus::static_for<frags>([&](auto i) {
                constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
                mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][0][m], v_b[0][0][n], v_c[0][0][m * T::E_N + n], v_sfa[0][0], v_sfb[0][0]);   // kk = 0
                mma_scale_one<T, m, n, c_reg<T, 0, 0, m, n>()>(mma, v_a[0][1][m], v_b[0][1][n], v_c[0][0][m * T::E_N + n], v_sfa[0][1], v_sfb[0][1]);   // kk = 1
            });
            sched_x4<8, 2, 0, 0>();
            __builtin_amdgcn_sched_barrier(0);
        });
        ++tile;
    }
    // 2. Last tile: C10, C01, C11.
    {
        // C10(t).
        opus::static_for<frags>([&](auto i) {
            constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
            mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][0][m], v_b[0][0][n], v_c[1][0][m * T::E_N + n], v_sfa[1][0], v_sfb[0][0]);   // kk = 0
            mma_scale_one<T, m, n, c_reg<T, 1, 0, m, n>()>(mma, v_a[1][1][m], v_b[0][1][n], v_c[1][0][m * T::E_N + n], v_sfa[1][1], v_sfb[0][1]);   // kk = 1
        });
        sched_x4<8, 0, 0, 0>();
        __builtin_amdgcn_sched_barrier(0);

        // C01(t).
        opus::static_for<frags>([&](auto i) {
            constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
            mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][0][m], v_b[1][0][n], v_c[0][1][m * T::E_N + n], v_sfa[0][0], v_sfb[1][0]);   // kk = 0
            mma_scale_one<T, m, n, c_reg<T, 0, 1, m, n>()>(mma, v_a[0][1][m], v_b[1][1][n], v_c[0][1][m * T::E_N + n], v_sfa[0][1], v_sfb[1][1]);   // kk = 1
        });
        sched_x4<8, 0, 0, 0>();
        __builtin_amdgcn_sched_barrier(0);

        // C11(t).
        opus::static_for<frags>([&](auto i) {
            constexpr int m = decltype(i)::value / T::E_N, n = decltype(i)::value % T::E_N;
            mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][0][m], v_b[1][0][n], v_c[1][1][m * T::E_N + n], v_sfa[1][0], v_sfb[1][0]);   // kk = 0
            mma_scale_one<T, m, n, c_reg<T, 1, 1, m, n>()>(mma, v_a[1][1][m], v_b[1][1][n], v_c[1][1][m * T::E_N + n], v_sfa[1][1], v_sfb[1][1]);   // kk = 1
        });
        sched_x4<8, 0, 0, 0>();
        __builtin_amdgcn_sched_barrier(0);
    }

    // 3. Write back C (bf16) through LDS, as opus_gemm_pipeline_a8w8_blockscale_mxscale_
    //    bpreshuffle_4wave_pin_agpr_gfx950 (PR 6696, Output::lds).  A wave owns only 16
    //    columns of a row per fragment (the other wave_n holds the neighbours), so direct
    //    fragment stores leave every 128-byte line partially written.  The whole 256 x 256
    //    tile is staged as one bf16 image in the idle A+B LDS, rows padded to B_N + 8
    //    elements (the 16 rows of a fragment then step by 16 bytes across the banks);
    //    each quadrant gets its own region, so staging needs no buffer reuse.  Per
    //    quadrant: stage -> sync -> 8 copies of 16 B per thread (one buffer_store = 4
    //    rows x 256 B), non-temporal (aux 2).
    constexpr int c_lds_stride = T::B_N + 8;
    constexpr int VEC_OUT = 16 / sizeof(D_C);                                            // 8 bf16 = 16 B
    static_assert(T::B_M * c_lds_stride * sizeof(D_C) <= smem_a_bytes + smem_b_bytes);
    auto s_c = make_smem(reinterpret_cast<D_C*>(smem_ab));
    auto p_coord_c = opus::make_tuple(wave_id_m, lane_id % mma.grpn_c, wave_id_n, lane_id / mma.grpn_c);
    auto u_sc = partition_layout_c<T::VEC_C>(mma, opus::make_tuple(opus::number<c_lds_stride>{}, 1_I), p_coord_c);
    auto sc_offset = [&](int half_tile_m, int half_tile_n) { return half_tile_m * T::HALF_B_M * c_lds_stride + half_tile_n * T::HALF_B_N; };
    const int output_thread_id = static_cast<int>(thread_id_x());
    // bf16 C: LDS -> global, one quadrant.
    auto copy_output_bf16 = [&](int half_tile_m, int half_tile_n) {
        opus::static_for<T::HALF_B_M * T::HALF_B_N / (T::BLOCK_SIZE * VEC_OUT)>([&](auto i) {   // 8
            const int linear = output_thread_id * VEC_OUT + decltype(i)::value * T::BLOCK_SIZE * VEC_OUT;
            const int r = linear / T::HALF_B_N + half_tile_m * T::HALF_B_M;
            const int c = linear % T::HALF_B_N + half_tile_n * T::HALF_B_N;
            const auto value = load<VEC_OUT>(s_c, r * c_lds_stride + c);
#ifdef DIAG_NO_STORE
            if (kargs.m < 0)   // diagnostic: never true
#endif
            store<VEC_OUT>(g_c, value, r * kargs.stride_c + c, 0, opus::number<2>{});
        });
    };
    // fp32 accumulators -> bf16 -> LDS, then sync and copy that quadrant out.
    auto store_quadrant = [&](const auto& acc, auto half_tile_m_, auto half_tile_n_) {
        constexpr int hm = decltype(half_tile_m_)::value, hn = decltype(half_tile_n_)::value;
        typename MMA::vtype_c quad;
        opus::static_for<T::E_M * T::E_N>([&](auto f) {
            opus::set_slice(quad, acc[f.value], opus::number<f.value * MMA::mma_c_len>{}, opus::number<(f.value + 1) * MMA::mma_c_len>{});
        });
        store<T::VEC_C>(s_c, cast<D_C>(quad), u_sc + sc_offset(hm, hn));
        __builtin_amdgcn_sched_barrier(0);
        if constexpr (!(hm == 1 && hn == 0)) s_waitcnt_vmcnt(0_I);
        s_waitcnt_lgkmcnt(0_I);
        __builtin_amdgcn_s_barrier();
        __builtin_amdgcn_sched_barrier(0);
        copy_output_bf16(hm, hn);
    };
    // All waves have finished their last matrix LDS reads.
    s_waitcnt_vmcnt(0_I);
    s_waitcnt_lgkmcnt(0_I);
    __builtin_amdgcn_s_barrier();
    __builtin_amdgcn_sched_barrier(0);
    store_quadrant(v_c[0][0], number<0>{}, number<0>{});
    store_quadrant(v_c[1][0], number<1>{}, number<0>{});
    store_quadrant(v_c[0][1], number<0>{}, number<1>{});
    store_quadrant(v_c[1][1], number<1>{}, number<1>{});
}
